# Récupérer le contenu du fichier exporté
$file = "C:\Users\$env:USERNAME\Desktop\SCEWIN_64\BIOSSettings.txt"
$newFile = "C:\Users\$env:USERNAME\Desktop\SCEWIN_64\BIOSSettings_modified.txt"

# Lire le contenu du fichier et traiter ligne par ligne
$lines = Get-Content $file
$modifiedLines = @()

foreach ($line in $lines) {
    # Ajouter l'en-tête sans modification
    if ($line -match "Copyright|Script File Name") {
        $modifiedLines += $line
    }

    # Identifier et modifier les paramètres spécifiques
    if ($line -match "Setup Question\s*=\s*(IOMMU|Spread Spectrum|SB Clock Spread Spectrum|SMT Control|...etc)") {
        $modifiedLines += $line
        $modifiedLines += "Token    =102    // Do NOT change this line"  # Par exemple, tu dois personnaliser le token et offset
        $modifiedLines += "Offset   =149"
        $modifiedLines += "Width    =01"
        $modifiedLines += "BIOS Default = [02]Auto"
        $modifiedLines += "Options  = [02]Auto    // Move '*' to the desired Option"
        $modifiedLines += "         *[00]Disabled"
        $modifiedLines += "         [01]Enabled"
    } else {
        # Ajouter les autres lignes non modifiées
        $modifiedLines += $line
    }
}

# Sauvegarder le fichier modifié
$modifiedLines | Set-Content $newFile
