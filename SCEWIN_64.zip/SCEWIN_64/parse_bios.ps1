<#
parse_bios.ps1 - Script "en béton" pour modifier les paramètres BIOS
Fonctionnalités:
1. Garde uniquement l'en-tête et les paramètres spécifiés
2. Met TOUS les paramètres cibles en Disabled
3. Supprime TOUT le reste
4. Respecte strictement le format du fichier
#>

# Liste EXACTE des paramètres à conserver (avec la casse exacte du fichier)
$targetSettings = @(
    "IOMMU",
    "Spread Spectrum",
    "SB Clock Spread Spectrum",
    "SMT Control",
    "AMD Cool'N'Quiet",
    "Fast Boot",
    "Global C-state Control",
    "Chipset Power Saving Features",
    "Remote Display Feature",
    "PS2 Devices Support",
    "Ipv6 PXE Support",
    "IPv6 HTTP Support",
    "PSS Support",
    "AB Clock Gating",
    "PCIB Clock Run",
    "Enable Hibernation",
    "SR-IOV Support",
    "BME DMA Mitigation",
    "Opcache Control"
)

# Chemins des fichiers
$biosFile = Join-Path $PSScriptRoot "BIOSSettings.txt"
$tempFile = Join-Path $PSScriptRoot "BIOSSettings_temp.txt"

# Vérification du fichier source
if (-not (Test-Path $biosFile)) {
    Write-Host "[ERREUR] Fichier BIOSSettings.txt introuvable!" -ForegroundColor Red
    exit 1
}

# Lecture du contenu
$content = Get-Content $biosFile -Raw

# Extraction de l'en-tête (tout jusqu'à HIICrc32 inclus)
$header = ""
if ($content -match "(?s)(.*?HIICrc32=.+?\r?\n\r?\n)(.*)") {
    $header = $matches[1]
    $remainingContent = $matches[2]
} else {
    $header = $content
    $remainingContent = ""
}

# Dictionnaire pour stocker les blocs valides (gère les doublons)
$validBlocks = [System.Collections.Generic.Dictionary[string, System.Collections.Generic.List[string]]::new()

# Découpage des blocs de paramètres
$blocks = $remainingContent -split '(?=\r?\nSetup Question\s*=)'

foreach ($block in $blocks) {
    if ($block -match 'Setup Question\s*=\s*(.+?)\r?\n') {
        $currentSetting = $matches[1].Trim()
        
        # Vérification si le paramètre est dans notre liste cible
        if ($targetSettings -contains $currentSetting) {
            # Traitement du bloc pour mettre en Disabled
            $processedBlock = $block -replace '(?s)(Options\s*=.*?\r?\n)(.*?)(\r?\n\r?\n|$)', {
                $optionsHeader = $args[0].Groups[1].Value
                $optionsContent = $args[0].Groups[2].Value
                $end = $args[0].Groups[3].Value
                
                # Trouver toutes les options
                $optionLines = $optionsContent -split '\r?\n' | Where-Object { $_ -match '\[[^\]]+\]' }
                
                # Trouver l'option Disabled
                $disabledLine = $optionLines | Where-Object { $_ -match '\[([^\]]+)\](Disabled|disabled|Disable|disable)' }
                
                if ($disabledLine) {
                    # Mettre * sur Disabled et enlever des autres
                    $newOptions = $optionLines | ForEach-Object {
                        if ($_ -eq $disabledLine) {
                            $_.Trim() -replace '^\s*\*?\s*', '*'
                        } else {
                            $_.Trim() -replace '^\s*\*?\s*', ' '
                        }
                    }
                    
                    # Reconstruire la section Options
                    $optionsHeader + ($newOptions -join "`r`n") + $end
                } else {
                    # Si Disabled n'existe pas, on garde le bloc mais sans modification
                    $args[0].Value
                }
            }
            
            # Stockage du bloc traité
            if (-not $validBlocks.ContainsKey($currentSetting)) {
                $validBlocks[$currentSetting] = [System.Collections.Generic.List[string]]::new()
            }
            $validBlocks[$currentSetting].Add($processedBlock)
        }
    }
}

# Reconstruction du contenu final
$finalContent = New-Object System.Text.StringBuilder
[void]$finalContent.Append($header)

# Ajout des blocs dans l'ordre de la liste cible
foreach ($setting in $targetSettings) {
    if ($validBlocks.ContainsKey($setting)) {
        foreach ($block in $validBlocks[$setting]) {
            [void]$finalContent.Append($block)
            [void]$finalContent.Append("`r`n`r`n")
        }
    }
}

# Écriture dans un fichier temporaire
$finalContent.ToString() | Out-File $tempFile -Encoding utf8 -NoNewline

# Remplacement du fichier original
try {
    Remove-Item $biosFile -Force -ErrorAction Stop
    Rename-Item $tempFile $biosFile -Force -ErrorAction Stop
    Write-Host "[SUCCÈS] Fichier BIOS modifié avec succès!" -ForegroundColor Green
    Write-Host "-> Seuls les paramètres cibles sont conservés" -ForegroundColor Cyan
    Write-Host "-> Tous les paramètres sont en Disabled" -ForegroundColor Cyan
    exit 0
} catch {
    Write-Host "[ERREUR] Impossible de remplacer le fichier: $_" -ForegroundColor Red
    exit 1
}