# Liste des paramètres ciblés
$targetSettings = @(
    "IOMMU", "Spread Spectrum", "SB Clock Spread Spectrum", "SMT Control", "AMD Cool'N'Quiet",
    "Fast Boot", "Global C-state Control", "Chipset Power Saving Features", "Remote Display Feature",
    "PS2 Devices Support", "Ipv6 PXE Support", "IPv6 HTTP Support", "PSS Support", "AB Clock Gating",
    "PCIB Clock Run", "Enable Hibernation", "SR-IOV Support", "BME DMA Mitigation", "Opcache Control"
)

# Fichiers
$biosFile = Join-Path $PSScriptRoot "BIOSSettings.txt"
$tempFile = Join-Path $PSScriptRoot "BIOSSettings_temp.txt"

if (-not (Test-Path $biosFile)) {
    Write-Host "[ERREUR] Fichier BIOS introuvable!" -ForegroundColor Red
    exit 1
}

$content = Get-Content $biosFile -Raw

# Header
$header = ""
if ($content -match "(?s)(.*?HIICrc32=.+?\r?\n\r?\n)(.*)") {
    $header = $matches[1]
    $remainingContent = $matches[2]
} else {
    $header = $content
    $remainingContent = ""
}

# Traitement blocs
$validBlocks = @()
$blocks = $remainingContent -split '(?=\r?\nSetup Question\s*=)'

foreach ($block in $blocks) {
    if ($block -match 'Setup Question\s*=\s*(.+?)\r?\n') {
        $settingName = $matches[1].Trim()

        if ($targetSettings -contains $settingName -and $block -match 'Options\s*=') {
            # Nettoyage et désactivation correcte
            $processedBlock = $block -replace '(?s)(Options\s*=.*?\r?\n)(.*?)(\r?\n\r?\n|$)', {
                param($match)
                $optionsHeader = $match.Groups[1].Value
                $optionsContent = $match.Groups[2].Value
                $end = $match.Groups[3].Value

                $newOptions = $optionsContent -split '\r?\n' | ForEach-Object {
                    if ($_ -match '\[([^\]]+)\](Disabled|disabled|Disable|disable)') {
                        $indent = ($_ -match '^\s+') ? $matches[0] : " "
                        "*$indent[$($matches[1])]$($matches[2])"
                    } elseif ($_ -match '\*') {
                        $_ -replace '\*', ' '
                    } else {
                        $_
                    }
                }

                $optionsHeader + ($newOptions -join "`r`n") + "`r`n"
            }

            # Vérifie que le bloc contient bien Setup Question et Options après traitement
            if ($processedBlock -match 'Setup Question\s*=' -and $processedBlock -match 'Options\s*=') {
                $validBlocks += $processedBlock.Trim()
            }
        }
    }
}

# Construction finale
$finalContent = $header + ($validBlocks -join "`r`n`r`n") + "`r`n"

# Sauvegarde
try {
    $finalContent | Out-File $tempFile -Encoding utf8 -NoNewline
    Move-Item $tempFile $biosFile -Force
    Write-Host "[SUCCÈS] Fichier BIOS nettoyé et modifié avec succès!" -ForegroundColor Green
    exit 0
} catch {
    Write-Host "[ERREUR] Échec de l'écriture: $_" -ForegroundColor Red
    exit 1
}
