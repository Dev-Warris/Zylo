$inputFile = "BIOSSettings.txt"
$outputFile = "BIOSSettings.txt"

# Liste blanche des paramètres à conserver
$allowedParams = @(
    "IOMMU",
    "Spread Spectrum",
    "SB Clock Spread Spectrum",
    "SMT Control",
    "AMD Cool'N'Quiet",
    "Fast Boot",
    "Global C-state Control",
    "Chipset Power Saving Features",
    "Remote Display Feature",
    "PS2 Devices Support",
    "Ipv6 PXE Support",
    "IPv6 HTTP Support",
    "PSS Support",
    "AB Clock Gating",
    "PCIB Clock Run",
    "SR-IOV Support",
    "BME DMA Mitigation",
    "Opcache Control"
)

$content = Get-Content $inputFile -Encoding ASCII

$header = @()
$body = @()
$inHeader = $true

# Séparer le header
foreach ($line in $content) {
    if ($inHeader) {
        $header += $line
        if ($line -match "^HIIcrc32=") {
            $inHeader = $false
        }
    } else {
        $body += $line
    }
}

$output = @()
$output += $header
$output += ""

$currentBlock = @()
$currentParam = ""
$insideBlock = $false

foreach ($line in $body) {
    if ($line -match "^Setup Question\s*=\s*(.+)$") {
        # Sauvegarder le bloc précédent si valide
        if ($currentBlock.Count -gt 0 -and $allowedParams -contains $currentParam) {
            $modifiedBlock = @()
            foreach ($bLine in $currentBlock) {
                $lineTrim = $bLine.TrimStart()
                # Supprimer tous les astérisques existants
                if ($lineTrim.StartsWith("*[")) {
                    $bLine = "         " + $lineTrim.Substring(1)
                }
                # Ajouter * devant [00]Disable ou [00]Disabled
                if ($bLine.Trim() -match "^\[\d{2}\](Disable|Disabled)\b" -and -not $bLine.Trim().StartsWith("*")) {
                    $bLine = $bLine -replace "^\s*(\[\d{2}\](Disable|Disabled))", '         *$1'
                }
                $modifiedBlock += $bLine
            }
            $output += $modifiedBlock
            $output += ""
        }
        $currentBlock = @($line)
        $currentParam = $matches[1].Trim()
        $insideBlock = $true
    }
    elseif ($insideBlock) {
        if ($line -match "^\s*$") {
            if ($allowedParams -contains $currentParam) {
                $modifiedBlock = @()
                foreach ($bLine in $currentBlock) {
                    $lineTrim = $bLine.TrimStart()
                    # Supprimer tous les astérisques existants
                    if ($lineTrim.StartsWith("*[")) {
                        $bLine = "         " + $lineTrim.Substring(1)
                    }
                    # Ajouter * devant [00]Disable ou [00]Disabled
                    if ($bLine.Trim() -match "^\[\d{2}\](Disable|Disabled)\b" -and -not $bLine.Trim().StartsWith("*")) {
                        $bLine = $bLine -replace "^\s*(\[\d{2}\](Disable|Disabled))", '         *$1'
                    }
                    $modifiedBlock += $bLine
                }
                $output += $modifiedBlock
                $output += ""
            }
            $currentBlock = @()
            $currentParam = ""
            $insideBlock = $false
        } else {
            $currentBlock += $line
        }
    }
}

# Dernier bloc à traiter
if ($currentBlock.Count -gt 0 -and $allowedParams -contains $currentParam) {
    $modifiedBlock = @()
    foreach ($bLine in $currentBlock) {
        $lineTrim = $bLine.TrimStart()
        # Supprimer tous les astérisques existants
        if ($lineTrim.StartsWith("*[")) {
            $bLine = "         " + $lineTrim.Substring(1)
        }
        # Ajouter * devant [00]Disable ou [00]Disabled
        if ($bLine.Trim() -match "^\[\d{2}\](Disable|Disabled)\b" -and -not $bLine.Trim().StartsWith("*")) {
            $bLine = $bLine -replace "^\s*(\[\d{2}\](Disable|Disabled))", '         *$1'
        }
        $modifiedBlock += $bLine
    }
    $output += $modifiedBlock
    $output += ""
}

# Écriture du fichier final
Set-Content -Path $outputFile -Value $output -Encoding ASCII