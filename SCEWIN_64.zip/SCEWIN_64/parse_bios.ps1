# Vérifie si le fichier de configuration BIOS existe
$biosFile = "C:\SCEWIN_64\SCEWIN_64\BIOSSettings.txt"

if (-Not (Test-Path $biosFile)) {
    Write-Host "[ERROR] Le fichier BIOSSettings.txt est introuvable."
    exit 1
}

# Charge le contenu du fichier
$lines = Get-Content $biosFile

# Liste des paramètres à modifier
$parametres = @(
    "IOMMU", 
    "Spread Spectrum", 
    "SB Clock Spread Spectrum", 
    "SMT Control", 
    "AMD Cool'N'Quiet", 
    "Fast Boot", 
    "Global C-state Control", 
    "Chipset Power Saving Features", 
    "Remote Display Feature", 
    "PS2 Devices Support", 
    "Ipv6 PXE Support", 
    "IPv6 HTTP Support", 
    "PSS Support", 
    "AB Clock Gating", 
    "PCIB Clock Run", 
    "Enable Hibernation", 
    "SR-IOV Support", 
    "BME DMA Mitigation", 
    "Opcache Control"
)

# Modification des paramètres dans le fichier BIOSSettings.txt
$modified = $false
foreach ($line in $lines) {
    foreach ($param in $parametres) {
        if ($line -match "^\s*$param\s*") {
            # Remplace le paramètre trouvé par "Disabled"
            $line = $line -replace "(?<=^\s*$param\s*).+", "Disabled"
            $modified = $true
            Write-Host "Le paramètre '$param' a été modifié à 'Disabled'."
        }
    }
}

# Si des modifications ont été effectuées, sauvegarder le fichier modifié
if ($modified) {
    Set-Content -Path $biosFile -Value $lines
    Write-Host "Modifications appliquées avec succès au fichier BIOSSettings.txt."
} else {
    Write-Host "Aucune modification nécessaire dans le fichier BIOSSettings.txt."
}
