<#
parse_bios.ps1 - Version Finale Corrigée
#>

# Liste EXACTE des paramètres à conserver
$targetSettings = @(
    "IOMMU",
    "Spread Spectrum",
    "SB Clock Spread Spectrum",
    "SMT Control",
    "AMD Cool'N'Quiet",
    "Fast Boot",
    "Global C-state Control",
    "Chipset Power Saving Features",
    "Remote Display Feature",
    "PS2 Devices Support",
    "Ipv6 PXE Support",
    "IPv6 HTTP Support",
    "PSS Support",
    "AB Clock Gating",
    "PCIB Clock Run",
    "Enable Hibernation",
    "SR-IOV Support",
    "BME DMA Mitigation",
    "Opcache Control"
)

# Chemins des fichiers
$biosFile = Join-Path $PSScriptRoot "BIOSSettings.txt"
$tempFile = Join-Path $PSScriptRoot "BIOSSettings_temp.txt"

# Vérification du fichier
if (-not (Test-Path $biosFile)) {
    Write-Host "[ERREUR] Fichier BIOS introuvable!" -ForegroundColor Red
    exit 1
}

# Lecture du contenu
$content = Get-Content $biosFile -Raw

# Extraction de l'en-tête (tout jusqu'à HIICrc32 inclus)
$header = ""
if ($content -match "(?s)(.*?HIICrc32=.+?\r?\n\r?\n)(.*)") {
    $header = $matches[1]
    $remainingContent = $matches[2]
} else {
    $header = $content
    $remainingContent = ""
}

# Tableau pour stocker les blocs valides
$validBlocks = @()

# Découpage et traitement des blocs
$blocks = $remainingContent -split '(?=\r?\nSetup Question\s*=)'

foreach ($block in $blocks) {
    if ($block -match 'Setup Question\s*=\s*(.+?)\r?\n') {
        $currentSetting = $matches[1].Trim()
        
        if ($targetSettings -contains $currentSetting) {
            # Traitement pour mettre en Disabled
            $processedBlock = $block -replace '(?s)(Options\s*=.*?\r?\n)(.*?)(\r?\n\r?\n|$)', {
                param($match)
                $optionsHeader = $match.Groups[1].Value
                $optionsContent = $match.Groups[2].Value
                $end = $match.Groups[3].Value
                
                $newOptions = $optionsContent -split '\r?\n' | ForEach-Object {
                    if ($_ -match '\[([^\]]+)\](Disabled|disabled|Disable|disable)') {
                        $indent = if ($_ -match '^\s+') { $matches[0] } else { " " }
                        "*$indent[$($matches[1])]$($matches[2])"
                    } elseif ($_ -match '\*') {
                        $_ -replace '\*', ' '
                    } else {
                        $_
                    }
                }
                
                $optionsHeader + ($newOptions -join "`r`n") + $end
            }
            
            $validBlocks += $processedBlock.Trim()
        }
    }
}

# Construction du contenu final
$finalContent = $header + ($validBlocks -join "`r`n`r`n")

# Écriture du fichier
try {
    $finalContent | Out-File $tempFile -Encoding utf8 -NoNewline
    Move-Item $tempFile $biosFile -Force
    Write-Host "[SUCCÈS] Fichier BIOS modifié avec succès!" -ForegroundColor Green
    Write-Host "- Seuls les paramètres cibles conservés" -ForegroundColor Cyan
    Write-Host "- Tous mis en Disabled" -ForegroundColor Cyan
    Write-Host "- Format strictement respecté" -ForegroundColor Cyan
    exit 0
} catch {
    Write-Host "[ERREUR] Échec de l'écriture: $_" -ForegroundColor Red
    exit 1
}