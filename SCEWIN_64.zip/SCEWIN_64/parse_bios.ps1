param (
    [string]$file = "$PSScriptRoot\SCEWIN_64\BIOSSettings.txt"
)

if (-not (Test-Path $file)) {
    Write-Host "[ERREUR] Le fichier $file n'existe pas."
    exit 1
}

Write-Host "[INFO] Chargement de $file..."

$lines = Get-Content $file
$output = @()
$inBlock = $false
$block = @()
$targetSettings = @(
    "IOMMU", "Spread Spectrum", "SB Clock Spread Spectrum", "SMT Control", "AMD Cool'N'Quiet",
    "Fast Boot", "Global C-state Control", "Chipset Power Saving Features", "Remote Display Feature",
    "PS2 Devices Support", "Ipv6 PXE Support", "IPv6 HTTP Support", "PSS Support", "AB Clock Gating",
    "PCIB Clock Run", "Enable Hibernation", "SR-IOV Support", "BME DMA Mitigation", "Opcache Control"
)

foreach ($line in $lines) {
    if ($line -match "^Setup Question\s*=\s*(.+)$") {
        $question = $matches[1].Trim()
        $inBlock = $true
        $block = @($line)
        continue
    }

    if ($inBlock) {
        $block += $line
        if ($line -match "^\s*\*\[") {
            if ($targetSettings -contains $question) {
                # Remplace l'option active par [00]Disabled si elle existe
                $modifiedBlock = $block -replace '^\s*\*\[(.*?)\](.*)$', {
                    if ($_.Value -match '\[00\]Disabled') {
                        return "         *[00]Disabled"
                    } else {
                        return $_.Value -replace '^\*', ' '
                    }
                }
                $output += $modifiedBlock
            } else {
                $output += $block
            }
            $inBlock = $false
            $block = @()
        }
    } else {
        $output += $line
    }
}

Write-Host "[INFO] Modifications appliquées. Écriture dans le fichier..."
$output | Set-Content $file -Encoding UTF8
