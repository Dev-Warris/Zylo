$inputFile = "BIOSSettings.txt"
$outputFile = "BIOSSettings.txt"

# Liste des paramètres BIOS à conserver et modifier
$allowedParams = @(
    "IOMMU",
    "Spread Spectrum",
    "SB Clock Spread Spectrum",
    "SMT Control",
    "AMD Cool'N'Quiet",
    "Fast Boot",
    "Global C-state Control",
    "Chipset Power Saving Features",
    "Remote Display Feature",
    "PS2 Devices Support",
    "Ipv6 PXE Support",
    "IPv6 HTTP Support",
    "PSS Support",
    "AB Clock Gating",
    "PCIB Clock Run",
    "Enable Hibernation",
    "SR-IOV Support",
    "BME DMA Mitigation",
    "Opcache Control"
)

$content = Get-Content $inputFile -Encoding ASCII

# Séparer le header du reste
$header = @()
$body = @()
$inHeader = $true

foreach ($line in $content) {
    if ($inHeader) {
        $header += $line
        if ($line -match "^HIIcrc32=") {
            $inHeader = $false
        }
    } else {
        $body += $line
    }
}

# Traitement des blocs
$output = @()
$output += $header
$output += ""  # ligne vide après le header

$currentBlock = @()
$currentParam = ""
$insideBlock = $false

foreach ($line in $body) {
    if ($line -match "^Setup Question\s*=\s*(.+)$") {
        if ($currentBlock.Count -gt 0 -and $allowedParams -contains $currentParam) {
            # Modifier le bloc précédent si autorisé
            $modifiedBlock = @()
            $starFound = $false

            foreach ($bLine in $currentBlock) {
                if ($bLine.Trim().StartsWith("*[")) {
                    # Retirer * si trouvé sur une option autre que "Disabled" ou "Disable"
                    if ($bLine.Trim() -match "^\[.{2}\](Disabled|Disable)\b") {
                        if ($starFound) {
                            $bLine = "         " + $bLine.Trim().Substring(1)  # Retirer le * si déjà trouvé
                        } else {
                            $bLine = "         *" + $bLine.Trim().Substring(1)  # Ajouter * uniquement sur Disabled/Disable
                            $starFound = $true
                        }
                    } else {
                        $bLine = "         " + $bLine.Trim().Substring(1)  # Retirer le * sur les autres options
                    }
                }

                $modifiedBlock += $bLine
            }
            $output += $modifiedBlock
            $output += ""
        }
        $currentBlock = @($line)
        $currentParam = $matches[1].Trim()
        $insideBlock = $true
    }
    elseif ($insideBlock) {
        if ($line -match "^\s*$") {
            if ($allowedParams -contains $currentParam) {
                # Modifier et ajouter le bloc
                $modifiedBlock = @()
                $starFound = $false
                foreach ($bLine in $currentBlock) {
                    if ($bLine.Trim().StartsWith("*[")) {
                        if ($bLine.Trim() -match "^\[.{2}\](Disabled|Disable)\b") {
                            if ($starFound) {
                                $bLine = "         " + $bLine.Trim().Substring(1)  # Retirer * si déjà trouvé
                            } else {
                                $bLine = "         *" + $bLine.Trim().Substring(1)  # Ajouter * uniquement sur Disabled/Disable
                                $starFound = $true
                            }
                        } else {
                            $bLine = "         " + $bLine.Trim().Substring(1)  # Retirer le * sur les autres options
                        }
                    }
                    $modifiedBlock += $bLine
                }
                $output += $modifiedBlock
                $output += ""
            }
            $currentBlock = @()
            $currentParam = ""
            $insideBlock = $false
        } else {
            $currentBlock += $line
        }
    }
}

# Dernier bloc si fichier sans saut final
if ($currentBlock.Count -gt 0 -and $allowedParams -contains $currentParam) {
    $modifiedBlock = @()
    $starFound = $false
    foreach ($bLine in $currentBlock) {
        if ($bLine.Trim().StartsWith("*[")) {
            if ($bLine.Trim() -match "^\[.{2}\](Disabled|Disable)\b") {
                if ($starFound) {
                    $bLine = "         " + $bLine.Trim().Substring(1)  # Retirer * si déjà trouvé
                } else {
                    $bLine = "         *" + $bLine.Trim().Substring(1)  # Ajouter * uniquement sur Disabled/Disable
                    $starFound = $true
                }
            } else {
                $bLine = "         " + $bLine.Trim().Substring(1)  # Retirer le * sur les autres options
            }
        }
        $modifiedBlock += $bLine
    }
    $output += $modifiedBlock
    $output += ""
}

# Sauvegarde propre
Set-Content -Path $outputFile -Value $output -Encoding ASCII
