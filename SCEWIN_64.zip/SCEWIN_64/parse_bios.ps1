$inputFile = "BIOSSettings.txt"
$outputFile = "BIOSSettings.txt"

# Liste des paramètres BIOS à conserver et modifier (enlever Enable Hibernation)
$allowedParams = @(
    "IOMMU",
    "Spread Spectrum",
    "SB Clock Spread Spectrum",
    "SMT Control",
    "AMD Cool'N'Quiet",
    "Fast Boot",
    "Global C-state Control",
    "Chipset Power Saving Features",
    "Remote Display Feature",
    "PS2 Devices Support",
    "Ipv6 PXE Support",
    "IPv6 HTTP Support",
    "PSS Support",
    "AB Clock Gating",
    "PCIB Clock Run",
    "SR-IOV Support",
    "BME DMA Mitigation",
    "Opcache Control"
)

$content = Get-Content $inputFile -Encoding ASCII

# Séparer le header du reste
$header = @()
$body = @()
$inHeader = $true

foreach ($line in $content) {
    if ($inHeader) {
        $header += $line
        if ($line -match "^HIIcrc32=") {
            $inHeader = $false
        }
    } else {
        $body += $line
    }
}

# Traitement des blocs
$output = @()
$output += $header
$output += ""  # ligne vide après le header

$currentBlock = @()
$currentParam = ""
$insideBlock = $false

foreach ($line in $body) {
    if ($line -match "^Setup Question\s*=\s*(.+)$") {
        if ($currentBlock.Count -gt 0 -and $allowedParams -contains $currentParam) {
            # Modifier le bloc précédent si autorisé
            $modifiedBlock = @()
            $starFound = $false
            $disableFound = $false

            foreach ($bLine in $currentBlock) {
                if ($bLine.Trim().StartsWith("*[")) {
                    # Vérifier si Disabled ou Disable est trouvé
                    if ($bLine.Trim() -match "^\[.{2}\](Disabled|Disable)\b") {
                        if (-not $starFound) {
                            # Ajouter * uniquement sur Disabled/Disable
                            $bLine = "         *" + $bLine.Trim().Substring(1)
                            $starFound = $true
                            $disableFound = $true
                        } else {
                            # Retirer le * si déjà trouvé
                            $bLine = "         " + $bLine.Trim().Substring(1)
                        }
                    } elseif ($bLine.Trim() -match "^\[.{2}\](Auto)\b") {
                        # Retirer le * si c'est sur Auto
                        $bLine = "         " + $bLine.Trim().Substring(1)
                    } else {
                        # Retirer le * sur les autres options
                        $bLine = "         " + $bLine.Trim().Substring(1)
                    }
                }
                $modifiedBlock += $bLine
            }

            # Si le bloc contient "Disabled" ou "Disable" mais que "*" n'a pas été ajouté, on l'ajoute
            if (-not $starFound -and ($disableFound)) {
                $modifiedBlock[0] = "         *" + $modifiedBlock[0].Trim().Substring(1)  # Ajouter * devant Disabled
            }

            $output += $modifiedBlock
            $output += ""
        }
        $currentBlock = @($line)
        $currentParam = $matches[1].Trim()
        $insideBlock = $true
    }
    elseif ($insideBlock) {
        if ($line -match "^\s*$") {
            if ($allowedParams -contains $currentParam) {
                # Modifier et ajouter le bloc
                $modifiedBlock = @()
                $starFound = $false
                $disableFound = $false
                foreach ($bLine in $currentBlock) {
                    if ($bLine.Trim().StartsWith("*[")) {
                        if ($bLine.Trim() -match "^\[.{2}\](Disabled|Disable)\b") {
                            if (-not $starFound) {
                                # Ajouter * uniquement sur Disabled/Disable
                                $bLine = "         *" + $bLine.Trim().Substring(1)
                                $starFound = $true
                                $disableFound = $true
                            } else {
                                # Retirer le * si déjà trouvé
                                $bLine = "         " + $bLine.Trim().Substring(1)
                            }
                        } elseif ($bLine.Trim() -match "^\[.{2}\](Auto)\b") {
                            # Retirer le * si c'est sur Auto
                            $bLine = "         " + $bLine.Trim().Substring(1)
                        } else {
                            # Retirer le * sur les autres options
                            $bLine = "         " + $bLine.Trim().Substring(1)
                        }
                    }
                    $modifiedBlock += $bLine
                }
                $output += $modifiedBlock
                $output += ""
            }
            $currentBlock = @()
            $currentParam = ""
            $insideBlock = $false
        } else {
            $currentBlock += $line
        }
    }
}

# Dernier bloc si fichier sans saut final
if ($currentBlock.Count -gt 0 -and $allowedParams -contains $currentParam) {
    $modifiedBlock = @()
    $starFound = $false
    $disableFound = $false
    foreach ($bLine in $currentBlock) {
        if ($bLine.Trim().StartsWith("*[")) {
            if ($bLine.Trim() -match "^\[.{2}\](Disabled|Disable)\b") {
                if (-not $starFound) {
                    # Ajouter * uniquement sur Disabled/Disable
                    $bLine = "         *" + $bLine.Trim().Substring(1)
                    $starFound = $true
                    $disableFound = $true
                } else {
                    # Retirer le * si déjà trouvé
                    $bLine = "         " + $bLine.Trim().Substring(1)
                }
            } elseif ($bLine.Trim() -match "^\[.{2}\](Auto)\b") {
                # Retirer le * si c'est sur Auto
                $bLine = "         " + $bLine.Trim().Substring(1)
            } else {
                # Retirer le * sur les autres options
                $bLine = "         " + $bLine.Trim().Substring(1)
            }
        }
        $modifiedBlock += $bLine
    }
    $output += $modifiedBlock
    $output += ""
}

# Sauvegarde propre
Set-Content -Path $outputFile -Value $output -Encoding ASCII
