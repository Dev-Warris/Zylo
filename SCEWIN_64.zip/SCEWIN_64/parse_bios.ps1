# Récupérer le contenu du fichier exporté
$file = "C:\Users\warri\Desktop\SCEWIN_64\BIOSSettings.txt"
$newFile = "C:\Users\warri\Desktop\SCEWIN_64\BIOSSettings_modified.txt"

# Vérifier si le fichier exporté existe
if (-Not (Test-Path $file)) {
    Write-Host "Le fichier $file n'existe pas."
    exit
}

# Lire le contenu du fichier et traiter ligne par ligne
$lines = Get-Content $file
$modifiedLines = @()

# Liste des paramètres à modifier
$parametersToModify = @(
    "Spread Spectrum", 
    "SB Clock Spread Spectrum",
    "IOMMU",
    "SMT Control",
    "AMD Cool'N'Quiet",
    "Fast Boot",
    "Global C-state Control",
    "Chipset Power Saving Features",
    "Remote Display Feature",
    "PS2 Devices Support",
    "Ipv6 PXE Support",
    "IPv6 HTTP Support",
    "PSS Support",
    "AB Clock Gating",
    "PCIB Clock Run",
    "Enable Hibernation",
    "SR-IOV Support",
    "BME DMA Mitigation",
    "Opcache Control"
)

foreach ($line in $lines) {
    # Ajouter l'en-tête sans modification
    if ($line -match "Copyright|Script File Name") {
        $modifiedLines += $line
    }

    # Identifier et modifier les paramètres spécifiques
    foreach ($param in $parametersToModify) {
        if ($line -match "Setup Question\s*=\s*$param") {
            # Si le paramètre est trouvé, ajouter les lignes correspondantes
            $modifiedLines += $line
            $modifiedLines += "Token    =102    // Do NOT change this line"  # Exemple de Token, à ajuster en fonction du paramètre
            $modifiedLines += "Offset   =149"
            $modifiedLines += "Width    =01"
            $modifiedLines += "BIOS Default = [02]Auto"
            $modifiedLines += "Options  = [02]Auto    // Move '*' to the desired Option"
            $modifiedLines += "         *[00]Disabled"  # Mettre l'option sur Disabled
            $modifiedLines += "         [01]Enabled"
            break
        }
    }
    
    # Ajouter les autres lignes non modifiées
    if ($modifiedLines[-1] -ne $line) {
        $modifiedLines += $line
    }
}

# Sauvegarder le fichier modifié
$modifiedLines | Set-Content $newFile
Write-Host "Fichier modifié sauvegardé sous : $newFile"
