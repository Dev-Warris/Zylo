# Définir le fichier d'entrée et de sortie
$inputFile = "BIOSSettings.txt"
$outputFile = "BIOSSettings.txt"

# Liste des paramètres BIOS à conserver
$allowedParams = @(
    "IOMMU",
    "Spread Spectrum",
    "SB Clock Spread Spectrum",
    "SMT Control",
    "AMD Cool'N'Quiet",
    "Fast Boot",
    "Global C-state Control",
    "Chipset Power Saving Features",
    "Remote Display Feature",
    "PS2 Devices Support",
    "Ipv6 PXE Support",
    "IPv6 HTTP Support",
    "PSS Support",
    "AB Clock Gating",
    "PCIB Clock Run",
    "SR-IOV Support",
    "BME DMA Mitigation",
    "Opcache Control"
)

# Charger le contenu du fichier
$content = Get-Content $inputFile -Encoding ASCII

# Initialisation des variables
$header = @()
$body = @()
$inHeader = $true

# Séparer le header du reste du fichier
foreach ($line in $content) {
    if ($inHeader) {
        $header += $line
        if ($line -match "^HIIcrc32=") {
            $inHeader = $false
        }
    } else {
        $body += $line
    }
}

# Liste pour stocker le fichier modifié
$output = @()
$output += $header
$output += ""  # Ligne vide après le header

$currentBlock = @()
$currentParam = ""
$insideBlock = $false

# Traitement des lignes du corps
foreach ($line in $body) {
    if ($line -match "^Setup Question\s*=\s*(.+)$") {
        # Si nous avons un bloc précédemment trouvé et qu'il est valide, le traiter
        if ($currentBlock.Count -gt 0 -and $allowedParams -contains $currentParam) {
            $modifiedBlock = @()

            # Modifier les lignes du bloc
            foreach ($bLine in $currentBlock) {
                # Supprimer tous les * du texte sauf pour [00]Disable et [00]Disabled
                $bLine = $bLine -replace '\*', ''

                # Ajouter un * devant [00]Disable et [00]Disabled
                if ($bLine.Trim() -match "^\[00\](Disable|Disabled)\b") {
                    if ($bLine.Trim() -notmatch "^\*") {
                        $bLine = "         *" + $bLine.Trim().Substring(1)
                    }
                }

                $modifiedBlock += $bLine
            }

            # Ajouter le bloc modifié au fichier de sortie
            $output += $modifiedBlock
            $output += ""
        }

        # Commencer un nouveau bloc
        $currentBlock = @($line)
        $currentParam = $matches[1].Trim()
        $insideBlock = $true
    }
    elseif ($insideBlock) {
        # Si une ligne vide est trouvée, terminer le bloc précédent
        if ($line -match "^\s*$") {
            if ($allowedParams -contains $currentParam) {
                $modifiedBlock = @()
                foreach ($bLine in $currentBlock) {
                    # Supprimer tous les * du texte sauf pour [00]Disable et [00]Disabled
                    $bLine = $bLine -replace '\*', ''

                    # Ajouter un * devant [00]Disable et [00]Disabled
                    if ($bLine.Trim() -match "^\[00\](Disable|Disabled)\b") {
                        if ($bLine.Trim() -notmatch "^\*") {
                            $bLine = "         *" + $bLine.Trim().Substring(1)
                        }
                    }

                    $modifiedBlock += $bLine
                }
                $output += $modifiedBlock
                $output += ""
            }
            $currentBlock = @()
            $currentParam = ""
            $insideBlock = $false
        } else {
            $currentBlock += $line
        }
    }
}

# Dernier bloc si le fichier n'a pas de saut final
if ($currentBlock.Count -gt 0 -and $allowedParams -contains $currentParam) {
    $modifiedBlock = @()
    foreach ($bLine in $currentBlock) {
        # Supprimer tous les * du texte sauf pour [00]Disable et [00]Disabled
        $bLine = $bLine -replace '\*', ''

        # Ajouter un * devant [00]Disable et [00]Disabled
        if ($bLine.Trim() -match "^\[00\](Disable|Disabled)\b") {
            if ($bLine.Trim() -notmatch "^\*") {
                $bLine = "         *" + $bLine.Trim().Substring(1)
            }
        }

        $modifiedBlock += $bLine
    }
    $output += $modifiedBlock
    $output += ""
}

# Sauvegarder le fichier modifié
Set-Content -Path $outputFile -Value $output -Encoding ASCII

Write-Host "Fichier modifié et sauvegardé avec succès !"
