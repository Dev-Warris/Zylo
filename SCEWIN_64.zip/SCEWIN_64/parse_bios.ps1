# Liste des paramètres BIOS à conserver
$keepParams = @(
    "IOMMU",
    "Spread Spectrum",
    "SB Clock Spread Spectrum",
    "SMT Control",
    "AMD Cool'N'Quiet",
    "Fast Boot",
    "Global C-state Control",
    "Chipset Power Saving Features",
    "Remote Display Feature",
    "PS2 Devices Support",
    "Ipv6 PXE Support",
    "IPv6 HTTP Support",
    "PSS Support",
    "AB Clock Gating",
    "PCIB Clock Run",
    "SR-IOV Support",
    "BME DMA Mitigation",
    "Opcache Control"
)

# Lecture du fichier d'entrée
$inputFile = "BIOSSettings.txt"
$outputFile = "BIOSSettings_Parsed.txt"
$content = Get-Content $inputFile -Raw

# Séparer chaque bloc de paramètre
$split = $content -split "(?=Setup Question\s*=)"

# Garder le header intact
$header = $split[0]
$blocks = $split[1..($split.Length - 1)]

# Filtrer les blocs à conserver
$filteredBlocks = @()

foreach ($block in $blocks) {
    if ($block -match "Setup Question\s*=\s*(.+)") {
        $paramName = $matches[1].Trim()
        if ($keepParams -contains $paramName) {

            # Supprimer tous les astérisques
            $cleanedBlock = ($block -split "`r?`n") | ForEach-Object {
                $_ -replace "\*", ""
            }

            # Remettre l'astérisque uniquement sur [00]Disable ou [00]Disabled
            $modifiedBlock = $cleanedBlock | ForEach-Object {
                if ($_ -match "^\s*\[00\]Disable(d)?") {
                    return ($_ -replace "^\s*(\[00\]Disable(d)?)", "         *$1")
                } else {
                    return $_
                }
            }

            # Ajouter au résultat
            $filteredBlocks += ($modifiedBlock -join "`r`n")
        }
    }
}

# Reconstruction finale du fichier
$output = $header + "`r`n" + ($filteredBlocks -join "`r`n`r`n")
Set-Content -Path $outputFile -Value $output -Encoding UTF8

Write-Host "✅ BIOSSettings_Parsed.txt ready with filtered and cleaned entries."
