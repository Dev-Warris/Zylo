$inputFile = "BIOSSettings.txt"
$outputFile = "BIOSSettings.txt"

# Liste des paramètres à modifier
$desiredSettings = @{
    "IOMMU"                          = "Disabled"
    "Spread Spectrum"               = "Disabled"
    "SB Clock Spread Spectrum"      = "Disabled"
    "SMT Control"                   = "Disabled"
    "AMD Cool'N'Quiet"              = "Disabled"
    "Fast Boot"                     = "Disabled"
    "Global C-state Control"        = "Disabled"
    "Chipset Power Saving Features" = "Disabled"
    "Remote Display Feature"        = "Disabled"
    "PS2 Devices Support"           = "Disabled"
    "Ipv6 PXE Support"              = "Disabled"
    "IPv6 HTTP Support"             = "Disabled"
    "PSS Support"                   = "Disabled"
    "AB Clock Gating"               = "Disabled"
    "PCIB Clock Run"                = "Disabled"
    "Enable Hibernation"            = "Disabled"
    "SR-IOV Support"                = "Disabled"
    "BME DMA Mitigation"            = "Disabled"
    "Opcache Control"               = "Disabled"
}

$content = Get-Content $inputFile

# Extraire le header (jusqu’à la ligne vide après le CRC)
$header = @()
$body = @()
$inHeader = $true

foreach ($line in $content) {
    if ($inHeader) {
        $header += $line
        if ($line -match "^HIIcrc32=") {
            $inHeader = $false
        }
    } else {
        $body += $line
    }
}

$output = @()
$output += $header
$output += ""  # ligne vide après le header comme dans ton exemple

$currentParam = ""
$block = @()
$inSetupBlock = $false

foreach ($line in $body) {
    if ($line -match "^Setup Question\s*=\s*(.+)$") {
        if ($block.Count -gt 0 -and $desiredSettings.ContainsKey($currentParam)) {
            $desiredValue = $desiredSettings[$currentParam]
            $modifiedBlock = @()

            foreach ($bLine in $block) {
                $stripped = $bLine.Trim()
                if ($stripped.StartsWith("*[")) {
                    $bLine = "         " + $stripped.Substring(1)
                }
                if ($stripped -match "^\[[0-9A-Fa-f]{2}\]$desiredValue") {
                    $bLine = "         *$stripped"
                }
                $modifiedBlock += $bLine
            }

            $output += $modifiedBlock
            $block = @()
        }

        $currentParam = $matches[1].Trim()
        $inSetupBlock = $true
        $block = @($line)
    }
    elseif ($inSetupBlock -and ($line -match "^\s*(\*?\[[0-9A-Fa-f]{2}\].*)$")) {
        $block += $line
    }
    else {
        if ($block.Count -gt 0 -and $desiredSettings.ContainsKey($currentParam)) {
            $desiredValue = $desiredSettings[$currentParam]
            $modifiedBlock = @()

            foreach ($bLine in $block) {
                $stripped = $bLine.Trim()
                if ($stripped.StartsWith("*[")) {
                    $bLine = "         " + $stripped.Substring(1)
                }
                if ($stripped -match "^\[[0-9A-Fa-f]{2}\]$desiredValue") {
                    $bLine = "         *$stripped"
                }
                $modifiedBlock += $bLine
            }

            $output += $modifiedBlock
            $block = @()
        }
        elseif ($block.Count -gt 0) {
            $output += $block
            $block = @()
        }

        $output += $line
        $inSetupBlock = $false
        $currentParam = ""
    }
}

# Écriture en ASCII pour compatibilité AMISCE
Set-Content -Path $outputFile -Value $output -Encoding ASCII
