$inputFile = "BIOSSettings.txt"
$outputFile = "BIOSSettings.txt"

# Liste des paramètres BIOS à conserver et modifier
$allowedParams = @(
    "IOMMU",
    "Spread Spectrum",
    "SB Clock Spread Spectrum",
    "SMT Control",
    "AMD Cool'N'Quiet",
    "Fast Boot",
    "Global C-state Control",
    "Chipset Power Saving Features",
    "Remote Display Feature",
    "PS2 Devices Support",
    "Ipv6 PXE Support",
    "IPv6 HTTP Support",
    "PSS Support",
    "AB Clock Gating",
    "PCIB Clock Run",
    "Enable Hibernation",
    "SR-IOV Support",
    "BME DMA Mitigation",
    "Opcache Control"
)

$content = Get-Content $inputFile -Encoding ASCII

# Séparer le header du reste
$header = @()
$body = @()
$inHeader = $true

foreach ($line in $content) {
    if ($inHeader) {
        $header += $line
        if ($line -match "^HIIcrc32=") {
            $inHeader = $false
        }
    } else {
        $body += $line
    }
}

# Traitement des blocs
$output = @()
$output += $header
$output += ""  # ligne vide après le header

$currentBlock = @()
$currentParam = ""
$insideBlock = $false

foreach ($line in $body) {
    if ($line -match "^Setup Question\s*=\s*(.+)$") {
        if ($currentBlock.Count -gt 0 -and $allowedParams -contains $currentParam) {
            $output += Modifier-Bloc $currentBlock
            $output += ""
        }
        $currentBlock = @($line)
        $currentParam = $matches[1].Trim()
        $insideBlock = $true
    }
    elseif ($insideBlock) {
        if ($line -match "^\s*$") {
            if ($allowedParams -contains $currentParam) {
                $output += Modifier-Bloc $currentBlock
                $output += ""
            }
            $currentBlock = @()
            $currentParam = ""
            $insideBlock = $false
        } else {
            $currentBlock += $line
        }
    }
}

# Dernier bloc si fichier sans saut final
if ($currentBlock.Count -gt 0 -and $allowedParams -contains $currentParam) {
    $output += Modifier-Bloc $currentBlock
    $output += ""
}

# Sauvegarde propre
Set-Content -Path $outputFile -Value $output -Encoding ASCII

# Fonction de modification des blocs
function Modifier-Bloc($bloc) {
    $modBloc = @()
    foreach ($line in $bloc) {
        $cleanLine = $line -replace "^\s*\*", "         "  # Nettoie les étoiles et réaligne
        if ($cleanLine.Trim() -match "^\[.{2}\](Disable|Disabled|01\]Disabled)\b") {
            $cleanLine = "         *" + $cleanLine.Trim()
        }
        $modBloc += $cleanLine
    }
    return $modBloc
}
