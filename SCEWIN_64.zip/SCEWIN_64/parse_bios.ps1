# Chemin du fichier BIOSSettings.txt
$biosFile = "C:\SCEWIN_64\SCEWIN_64\BIOSSettings.txt"

# Liste des paramètres à désactiver
$parametres = @(
    "IOMMU", 
    "Spread Spectrum", 
    "SB Clock Spread Spectrum", 
    "SMT Control", 
    "AMD Cool'N'Quiet", 
    "Fast Boot", 
    "Global C-state Control", 
    "Chipset Power Saving Features", 
    "Remote Display Feature", 
    "PS2 Devices Support", 
    "Ipv6 PXE Support", 
    "IPv6 HTTP Support", 
    "PSS Support", 
    "AB Clock Gating", 
    "PCIB Clock Run", 
    "Enable Hibernation", 
    "SR-IOV Support", 
    "BME DMA Mitigation", 
    "Opcache Control"
)

# Lire le contenu du fichier BIOSSettings.txt
$lines = Get-Content $biosFile

# Variables pour maintenir l'état du fichier (préserver l'en-tête)
$modified = $false
$updatedLines = @()

# Variable pour déterminer si on est dans une section de paramètre à modifier
$insideParamSection = $false
$currentParam = ""

foreach ($line in $lines) {
    # Garder l'en-tête intact
    if ($line -match "^//") {
        $updatedLines += $line
        continue
    }

    # Si on détecte une section de paramètre, on l'analyse
    if ($line -match "^Setup Question\s*=\s*(.*)$") {
        $currentParam = $matches[1].Trim()
        $insideParamSection = $parametres -contains $currentParam
    }

    # Si on est dans une section et qu'on trouve les options, on modifie
    if ($insideParamSection -and $line -match "^\s*\[\d+\]") {
        # Remplacer la ligne avec "*[00]Disabled"
        if ($line -match "^\s*\[00\]Disabled") {
            $updatedLines += $line
        } else {
            $updatedLines += "         *[00]Disabled"  # Ajouter le "*"
        }
        $modified = $true
        $insideParamSection = $false  # Quitter la section de paramètre après modification
    }
    else {
        # Sinon, ajouter la ligne telle quelle
        $updatedLines += $line
    }
}

# Si des modifications ont été faites, on sauvegarde le fichier
if ($modified) {
    Set-Content -Path $biosFile -Value $updatedLines
    Write-Host "Modifications appliquées avec succès au fichier BIOSSettings.txt."
} else {
    Write-Host "Aucune modification nécessaire dans le fichier BIOSSettings.txt."
}
