# parse_bios.ps1 - Version Finale Corrigée

$inputFile = "BIOSSettings.txt"
$outputFile = "BIOSSettings.txt"

# Liste des paramètres BIOS à conserver
$allowedParams = @(
    "IOMMU", "Spread Spectrum", "SB Clock Spread Spectrum", "SMT Control",
    "AMD Cool'N'Quiet", "Fast Boot", "Global C-state Control",
    "Chipset Power Saving Features", "Remote Display Feature",
    "PS2 Devices Support", "Ipv6 PXE Support", "IPv6 HTTP Support",
    "PSS Support", "AB Clock Gating", "PCIB Clock Run",
    "Enable Hibernation", "SR-IOV Support", "BME DMA Mitigation", 
    "Opcache Control"
)

# Lire le contenu en conservant les sauts de ligne
$content = Get-Content $inputFile -Raw

# Séparer l'en-tête du reste
$header = ""
$body = ""
if ($content -match "(?s)(.*?HIICrc32=.+?\r?\n\r?\n)(.*)") {
    $header = $matches[1]
    $body = $matches[2]
} else {
    $header = $content
    $body = ""
}

# Traitement des blocs
$output = New-Object System.Text.StringBuilder
[void]$output.Append($header.Trim())
[void]$output.AppendLine()
[void]$output.AppendLine()

$blocks = $body -split '(?=\r?\nSetup Question\s*=)'

foreach ($block in $blocks) {
    if ($block -match 'Setup Question\s*=\s*(.+?)\r?\n') {
        $currentParam = $matches[1].Trim()
        
        if ($allowedParams -contains $currentParam) {
            # Traitement du bloc pour mettre Disabled/Disable en premier
            $processedBlock = $block -replace '(?s)(Options\s*=.*?\r?\n)(.*?)(\r?\n|$)', {
                $optionsHeader = $args.Groups[1].Value
                $optionsContent = $args.Groups[2].Value
                $end = $args.Groups[3].Value
                
                $optionLines = $optionsContent -split '\r?\n' | Where-Object { $_ -match '\[[^\]]+\]' }
                
                # Traiter chaque ligne d'option
                $newOptions = @()
                foreach ($line in $optionLines) {
                    $trimmedLine = $line.Trim()
                    
                    if ($trimmedLine -match '^\*?\[([^\]]+)\](Disabled|Disable)\b') {
                        # Mettre * devant Disabled/Disable
                        $newOptions += "*$trimmedLine"
                    } elseif ($trimmedLine -match '^\*') {
                        # Enlever * des autres options
                        $newOptions += $trimmedLine.Substring(1)
                    } else {
                        $newOptions += $trimmedLine
                    }
                }
                
                # Reconstruire avec l'indentation correcte
                $indentedOptions = $newOptions | ForEach-Object {
                    if ($_.StartsWith("*")) {
                        "         $_"
                    } else {
                        "         $_"
                    }
                }
                
                $optionsHeader + ($indentedOptions -join "`r`n") + $end
            }
            
            [void]$output.AppendLine($processedBlock.Trim())
            [void]$output.AppendLine()
        }
    }
}

# Sauvegarde du fichier
try {
    $output.ToString() | Out-File $outputFile -Encoding ASCII -NoNewline
    Write-Host "Fichier BIOS modifié avec succès!" -ForegroundColor Green
} catch {
    Write-Host "Erreur lors de l'écriture du fichier: $_" -ForegroundColor Red
    exit 1
}