# parse_bios.ps1

# Liste des paramètres BIOS à modifier (exactement comme dans le fichier)
$targetSettings = @(
    "IOMMU",
    "Spread Spectrum",
    "SB Clock Spread Spectrum",
    "SMT Control",
    "AMD Cool'N'Quiet",
    "Fast Boot",
    "Global C-state Control",
    "Chipset Power Saving Features",
    "Remote Display Feature",
    "PS2 Devices Support",
    "Ipv6 PXE Support",
    "IPv6 HTTP Support",
    "PSS Support",
    "AB Clock Gating",
    "PCIB Clock Run",
    "Enable Hibernation",
    "SR-IOV Support",
    "BME DMA Mitigation",
    "Opcache Control"
)

# Chemins des fichiers
$biosFile = Join-Path $PSScriptRoot "BIOSSettings.txt"
$tempFile = Join-Path $PSScriptRoot "BIOSSettings_temp.txt"

# Vérifier si le fichier existe
if (-not (Test-Path $biosFile)) {
    Write-Host "[ERROR] Fichier BIOSSettings.txt introuvable."
    exit 1
}

# Lire tout le contenu du fichier
$content = Get-Content $biosFile -Raw

# Séparer l'en-tête du reste du contenu
$header = ""
$settings = $content

# Trouver la fin de l'en-tête (après HIICrc32)
if ($content -match "(?s)(.*?HIICrc32=.+?\r?\n\r?\n)(.*)") {
    $header = $matches[1]
    $settings = $matches[2]
}

# Traiter chaque bloc de paramètres
$processedSettings = $settings -split '(?=\r?\nSetup Question\s*=)' | ForEach-Object {
    if ($_ -match 'Setup Question\s*=\s*(.+?)\r?\n') {
        $currentSetting = $matches[1].Trim()
        
        # Vérifier si ce paramètre est dans notre liste cible
        if ($targetSettings -contains $currentSetting) {
            $block = $_
            
            # Trouver la ligne Options et modifier pour mettre * sur Disabled
            if ($block -match '(?s)(.*Options\s*=\s*\[.*?\].*?\r?\n)(\s*)(\*?\[.*?\].*?\r?\n)(.*)') {
                $beforeOptions = $matches[1]
                $indentation = $matches[2]
                $firstOption = $matches[3]
                $otherOptions = $matches[4]
                
                # Extraire toutes les options
                $optionsLines = $otherOptions -split '\r?\n' | Where-Object { $_ -match '\[\d+\]' }
                $allOptions = ,$firstOption + $optionsLines
                
                # Trouver l'option Disabled (peut être [00] ou autre selon le paramètre)
                $disabledOption = $allOptions | Where-Object { $_ -match '\[([^\]]+)\](Disabled|disabled|Disable|disable)' }
                
                if ($disabledOption) {
                    # Mettre * sur l'option Disabled et l'enlever des autres
                    $modifiedOptions = $allOptions | ForEach-Object {
                        if ($_ -eq $disabledOption) {
                            $indent = if ($_ -match '^\s+') { $matches[0] } else { "" }
                            $optValue = if ($_ -match '\[([^\]]+)\]') { $matches[1] } else { "" }
                            "$indent*[$optValue]$($matches[2])"
                        }
                        elseif ($_ -match '\*') {
                            $_ -replace '\*', ' '
                        }
                        else {
                            $_
                        }
                    }
                    
                    # Reconstruire le bloc avec les options modifiées
                    $newOptionsSection = $beforeOptions + ($modifiedOptions -join "`r`n")
                    $block = $block -replace '(?s)(.*Options\s*=\s*\[.*?\].*?\r?\n)(.*)', $newOptionsSection
                }
            }
            
            $block
        }
        else {
            # Si ce n'est pas un paramètre cible, le laisser inchangé
            $_
        }
    }
    else {
        $_
    }
}

# Reconstruire le contenu complet avec l'en-tête et les paramètres modifiés
$newContent = $header + ($processedSettings -join "")

# Écrire dans un fichier temporaire d'abord
$newContent | Out-File $tempFile -Encoding utf8 -NoNewline

# Remplacer l'ancien fichier par le nouveau
Remove-Item $biosFile -Force
Rename-Item $tempFile $biosFile

Write-Host "Paramètres BIOS spécifiques modifiés avec succès - toutes les options cibles sont désormais sur Disabled."
exit 0