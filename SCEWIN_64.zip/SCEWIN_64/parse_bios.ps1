# Version du script PowerShell pour la modification des paramètres BIOS avec détection complète

# Chemin du fichier BIOSSettings.txt
$filePath = "C:\SCEWIN_64\SCEWIN_64\BIOSSettings.txt"
$outputFilePath = "C:\SCEWIN_64\SCEWIN_64\BIOSSettings_modified.txt"

# Liste des paramètres BIOS à modifier
$biosParameters = @(
    'IOMMU',
    'Spread Spectrum',
    'SB Clock Spread Spectrum',
    'SMT Control',
    'AMD Cool\'N\'Quiet',
    'Fast Boot',
    'Global C-state Control',
    'Chipset Power Saving Features',
    'Remote Display Feature',
    'PS2 Devices Support',
    'Ipv6 PXE Support',
    'IPv6 HTTP Support',
    'PSS Support',
    'AB Clock Gating',
    'PCIB Clock Run',
    'SR-IOV Support',
    'BME DMA Mitigation',
    'Opcache Control'
)

# Fonction pour vérifier si la ligne correspond à un paramètre BIOS
function Is-BiosParameterLine {
    param(
        [string]$line
    )

    foreach ($param in $biosParameters) {
        if ($line -match "Setup Question\s+=\s+$param") {
            return $true
        }
    }

    return $false
}

# Fonction pour modifier une ligne de texte
function Modify-BiosSettings {
    param(
        [string]$line
    )

    # Vérifier si la ligne contient un paramètre à modifier
    foreach ($param in $biosParameters) {
        if ($line -match "Setup Question\s+=\s+$param") {
            Write-Host "Modification du paramètre : $param"

            # Modification de l'option Disabled/Disable
            if ($line -match 'Options=\[00\](Disabled|Disable)') {
                Write-Host "Modification de l'option [00]Disabled/Disable"
                $line = $line -replace '(\[00\])(Disabled|Disable)', '*$1$2'
            }

            # Forcer la modification des paramètres qui doivent être "Disabled"
            $line = $line -replace '\[00\]Auto', '[00]Disabled'

            # Si l'option est "Enabled", la mettre à "Disabled"
            if ($line -match '\[01\]Enabled') {
                Write-Host "Modification de [01]Enabled à [00]Disabled"
                $line = $line -replace '\[01\]Enabled', '[00]Disabled'
            }

            # Si l'option est "Auto", la mettre à "Disabled"
            if ($line -match '\[02\]Auto') {
                Write-Host "Modification de [02]Auto à [00]Disabled"
                $line = $line -replace '\[02\]Auto', '[00]Disabled'
            }

            # Remplacer les autres options Auto par Disabled
            if ($line -match '\[03\]Auto') {
                Write-Host "Modification de [03]Auto à [00]Disabled"
                $line = $line -replace '\[03\]Auto', '[00]Disabled'
            }
        }
    }

    return $line
}

# Fonction pour détecter si le fichier BIOS existe
function Check-FileExistence {
    param(
        [string]$file
    )

    if (-Not (Test-Path $file)) {
        Write-Host "Erreur : Le fichier $file n'existe pas !"
        exit
    }

    Write-Host "Le fichier $file existe, préparation à la modification..."
}

# Fonction pour sauvegarder le fichier modifié
function Save-ModifiedFile {
    param(
        [array]$content,
        [string]$outputFile
    )

    try {
        $content | Set-Content $outputFile
        Write-Host "Le fichier a été modifié et sauvegardé sous : $outputFile"
    }
    catch {
        Write-Host "Erreur lors de la sauvegarde du fichier modifié : $_"
        exit
    }
}

# Fonction pour appliquer les modifications ligne par ligne
function Apply-Changes {
    param(
        [array]$content
    )

    $modifiedContent = @()
    $lineCounter = 0

    foreach ($line in $content) {
        $lineCounter++

        # Si la ligne correspond à un paramètre BIOS à modifier
        if (Is-BiosParameterLine -line $line) {
            Write-Host "Modification en cours de la ligne $lineCounter"
            $line = Modify-BiosSettings -line $line
        }
        $modifiedContent += $line
    }

    return $modifiedContent
}

# Fonction pour créer un rapport de modification
function Create-Report {
    param(
        [string]$outputFile
    )

    $date = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
    $reportPath = "C:\SCEWIN_64\SCEWIN_64\Modification_Report_$date.txt"

    try {
        $report = "Rapport de modification des paramètres BIOS - $date`r`n"
        $report += "Fichier modifié : $outputFile`r`n"
        $report += "----------------------------------------`r`n"
        $report += "Paramètres BIOS modifiés :`r`n"

        foreach ($param in $biosParameters) {
            $report += "$param : Désactivé`r`n"
        }

        Set-Content -Path $reportPath -Value $report
        Write-Host "Le rapport de modification a été généré : $reportPath"
    }
    catch {
        Write-Host "Erreur lors de la création du rapport : $_"
    }
}

# Fonction principale pour exécuter l'ensemble du processus
function Main {
    Check-FileExistence -file $filePath

    # Lire le fichier original
    $content = Get-Content $filePath

    # Appliquer les modifications
    $modifiedContent = Apply-Changes -content $content

    # Sauvegarder le fichier modifié
    Save-ModifiedFile -content $modifiedContent -outputFile $outputFilePath

    # Créer un rapport de modification
    Create-Report -outputFile $outputFilePath
}

# Exécution du script principal
Main
