# Liste des paramètres BIOS à conserver
$desiredSettings = @(
    "IOMMU", 
    "Spread Spectrum", 
    "SB Clock Spread Spectrum", 
    "SMT Control", 
    "AMD Cool'N'Quiet", 
    "Fast Boot", 
    "Global C-state Control", 
    "Chipset Power Saving Features", 
    "Remote Display Feature", 
    "PS2 Devices Support", 
    "Ipv6 PXE Support", 
    "IPv6 HTTP Support", 
    "PSS Support", 
    "AB Clock Gating", 
    "PCIB Clock Run", 
    "Enable Hibernation", 
    "SR-IOV Support", 
    "BME DMA Mitigation", 
    "Opcache Control"
)

# Liste des paramètres BIOS dans le format que tu utilises pour l'import
$biosSettings = @(
    @{ "Question" = "Spread Spectrum"; "Token" = "102"; "Offset" = "149"; "Width" = "01"; "Default" = "[02]Auto"; "Options" = @( "00", "Disabled", "01", "Enabled") },
    @{ "Question" = "SMT Control"; "Token" = "1C"; "Offset" = "30"; "Width" = "01"; "Default" = "[01]Auto"; "Options" = @( "00", "Disabled", "01", "Enabled") },
    @{ "Question" = "Global C-state Control"; "Token" = "12"; "Offset" = "24"; "Width" = "01"; "Default" = "[00]Disabled"; "Options" = @( "00", "Disabled", "01", "Enabled") },
    @{ "Question" = "IOMMU"; "Token" = "DF"; "Offset" = "149"; "Width" = "01"; "Default" = "[01]Enabled"; "Options" = @( "00", "Disabled", "01", "Enabled") }
)

# Chemin du fichier d'export BIOS
$biosFile = "C:\SCEWIN_64\BIOSSettings.txt"

# Lire le fichier d'export
$lines = Get-Content -Path $biosFile

# Garder uniquement les lignes correspondant aux paramètres listés
$filteredLines = $lines | Where-Object { 
    $line = $_
    $desiredSettings | ForEach-Object { $line -match $_ }
}

# Créer une nouvelle liste de paramètres uniquement pour ceux qui sont dans la liste $biosSettings
$modifiedLines = @()
foreach ($setting in $biosSettings) {
    # Vérifier si le paramètre est présent dans le fichier exporté
    $paramLine = $filteredLines | Where-Object { $_ -match $setting["Question"] }
    
    if ($paramLine) {
        $modifiedLines += "Setup Question    = " + $setting["Question"]
        $modifiedLines += "Token        =" + $setting["Token"] + "    // Do NOT change this line"
        $modifiedLines += "Offset        =" + $setting["Offset"]
        $modifiedLines += "Width        =" + $setting["Width"]
        $modifiedLines += "BIOS Default    =" + $setting["Default"]

        # Créer les options avec "*" devant l'option sélectionnée (par défaut "Disabled")
        $modifiedLines += "Options        =[ " + $setting["Options"][0] + "]" + "Disabled" + "    // Move \"*\" to the desired Option"
        $modifiedLines += "            *[" + $setting["Options"][1] + "]" + "Enabled"

        $modifiedLines += ""  # Ajouter une ligne vide pour séparer les sections
    }
}

# Sauvegarder les lignes modifiées dans le fichier d'export
Set-Content -Path $biosFile -Value $modifiedLines

Write-Host "Le fichier des paramètres BIOS a été modifié et sauvegardé dans $biosFile"
