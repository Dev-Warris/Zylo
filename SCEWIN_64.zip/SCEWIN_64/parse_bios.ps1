<#
Script : parse_bios.ps1
Objectif : Ne garder que les paramètres listés, tout en forçant "*[xx]Disabled" et supprimant les autres "*"
Format strictement conforme à un export SCEWIN (Token, Offset, Width, etc.)
#>

# Liste exacte des paramètres à conserver
$targetSettings = @(
    "IOMMU", "Spread Spectrum", "SB Clock Spread Spectrum", "SMT Control", "AMD Cool'N'Quiet",
    "Fast Boot", "Global C-state Control", "Chipset Power Saving Features", "Remote Display Feature",
    "PS2 Devices Support", "Ipv6 PXE Support", "IPv6 HTTP Support", "PSS Support", "AB Clock Gating",
    "PCIB Clock Run", "Enable Hibernation", "SR-IOV Support", "BME DMA Mitigation", "Opcache Control"
)

# Fichiers
$biosFile = Join-Path $PSScriptRoot "BIOSSettings.txt"
$tempFile = Join-Path $PSScriptRoot "BIOSSettings_temp.txt"

if (-not (Test-Path $biosFile)) {
    Write-Host "[ERREUR] BIOSSettings.txt introuvable." -ForegroundColor Red
    exit 1
}

# Lecture complète
$content = Get-Content $biosFile -Raw

# Extraction du header
if ($content -match "(?s)(.*?HIICrc32=.+?\r?\n\r?\n)(.*)") {
    $header = $matches[1]
    $body = $matches[2]
} else {
    Write-Host "[ERREUR] Header non détecté." -ForegroundColor Red
    exit 1
}

# Séparation des blocs
$blocks = $body -split '(?=\r?\nSetup Question\s*=)'

# Nouveau contenu à construire
$validBlocks = @()

foreach ($block in $blocks) {
    if ($block -match "Setup Question\s*=\s*(.+?)\r?\n") {
        $name = $matches[1].Trim()

        if ($targetSettings -contains $name) {
            # Traitement du bloc Options
            $modifiedBlock = $block -replace '(?s)(Options\s*=\s*\r?\n)(.*?)(\r?\n\r?\n|$)', {
                param($match)
                $header = $match.Groups[1].Value
                $options = $match.Groups[2].Value
                $ending = $match.Groups[3].Value

                $lines = $options -split '\r?\n'
                $newLines = @()

                foreach ($line in $lines) {
                    $trimmed = $line.TrimStart()

                    if ($trimmed -match '^\*?\s*\[([^\]]+)\](.+)$') {
                        $index = $matches[1]
                        $value = $matches[2].Trim()

                        if ($value -ieq "Disabled") {
                            $newLines += "         *[$index]$value"
                        } else {
                            $newLines += "          [$index]$value"
                        }
                    } else {
                        $newLines += $line
                    }
                }

                return $header + ($newLines -join "`r`n") + $ending
            }

            $validBlocks += $modifiedBlock.Trim()
        }
    }
}

# Sortie complète
$final = $header + ($validBlocks -join "`r`n`r`n") + "`r`n"

try {
    $final | Out-File $tempFile -Encoding utf8 -NoNewline
    Move-Item $tempFile $biosFile -Force
    Write-Host "[SUCCÈS] Le fichier a été nettoyé et corrigé au format SCEWIN." -ForegroundColor Green
    exit 0
} catch {
    Write-Host "[ERREUR] Écriture impossible : $_" -ForegroundColor Red
    exit 1
}
