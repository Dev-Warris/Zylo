# Define the list of BIOS settings to change
$biosSettings = @(
    @{ "Question" = "Spread Spectrum"; "Token" = "102"; "Offset" = "149"; "Width" = "01"; "Default" = "[02]Auto"; "Options" = @([ "00", "Disabled" ], [ "01", "Enabled" ]) },
    @{ "Question" = "SMT Control"; "Token" = "1C"; "Offset" = "30"; "Width" = "01"; "Default" = "[01]Auto"; "Options" = @([ "00", "Disabled" ], [ "01", "Auto" ]) },
    @{ "Question" = "Global C-state Control"; "Token" = "12"; "Offset" = "24"; "Width" = "01"; "Default" = "[00]Disabled"; "Options" = @([ "00", "Disabled" ], [ "01", "Enabled" ]) },
    @{ "Question" = "SMT Control"; "Token" = "2D"; "Offset" = "28B"; "Width" = "01"; "Default" = "[01]Auto"; "Options" = @([ "00", "Disable" ], [ "01", "Auto" ]) },
    @{ "Question" = "IOMMU"; "Token" = "DF"; "Offset" = "149"; "Width" = "01"; "Default" = "[01]Enabled"; "Options" = @([ "00", "Disabled" ], [ "01", "Enabled" ]) }
)

# Initialize the output file path
$outputFile = "C:\SCEWIN_64\SCEWIN_64\BIOSSettings.txt"

# Open the output file for writing
$fs = New-Object System.IO.StreamWriter($outputFile, $false)

# Write the header
$fs.WriteLine("// Script File Name : BIOSSettings.txt")
$fs.WriteLine("// Created on " + (Get-Date -Format "MM/dd/yy HH:mm:ss"))
$fs.WriteLine("// Copyright (c)2018 American Megatrends, Inc.")
$fs.WriteLine("// AMISCE Utility. Ver 5.03.1115")
$fs.WriteLine("")

# Loop through each setting and write it in the desired format
foreach ($setting in $biosSettings) {
    $fs.WriteLine("Setup Question    = " + $setting["Question"])
    $fs.WriteLine("Token        =" + $setting["Token"] + "    // Do NOT change this line")
    $fs.WriteLine("Offset        =" + $setting["Offset"])
    $fs.WriteLine("Width        =" + $setting["Width"])
    $fs.WriteLine("BIOS Default    =" + $setting["Default"])
    
    $fs.WriteLine("Options        =[ " + $setting["Options"][0][0] + "]" + $setting["Options"][0][1] + "    // Move \"*\" to the desired Option")
    $fs.WriteLine("            *[" + $setting["Options"][1][0] + "]" + $setting["Options"][1][1])
    $fs.WriteLine("")

# Close the file
$fs.Close()

Write-Host "BIOS Settings file has been written to $outputFile"
